Index of lesson files for "Creating a Wordpress Theme"

This document represents a list of the lesson files used in this video series as well as any relevant notes. If you have questions or concerns about these videos please email us at gymhelp@aquent.com.

Chapter 1 - No lesson files


Chapter 2 - No lesson files

Chapter 3
├── 3-2.php
└── start_html
├── about.html
├── images
│ ├── glenn-ikea.jpg
│ ├── hamburger.png
│ ├── logo-long.png
│ └── logo.png
├── index.html
└── style.css

Chapter 4
├── loopy-loops
│ ├── images
│ │ ├── glenn-ikea.jpg
│ │ ├── hamburger.png
│ │ ├── logo-long.png
│ │ └── logo.png
│ ├── index.php
│ └── style.css
├── multiple_loops.txt
└── simple_loop.txt

Chapter 5
├── 5_starter_html
│ ├── images
│ ├── glenn-ikea.jpg
│ │ ├─ hamburger.png
│ │ ├── logo-long.png
│ │ └── logo.png
│ ├── index.html
│ └── style.css
└── snippets-5.txt

Chapter 6
├── glenns-theme
│ ├── front-page.php
│ ├── functions.php
│ ├── header.php
│ ├── images
│ │ ├── glenn-ikea.jpg
│ │ ├── hamburger.png
│ │ ├── logo-long.png
│ │ └── logo.png
│ ├── index.php
│ ├── page.php
│ ├── sidebar.php
│ ├── single.php
│ ├── style.css
│ ├── tpl_blog.php
│ └── tpl_page_with_sidebar.php
└── wordpress.glenns-site.xml

Chapter 7 - There are no lesson files for this chapter. This video is dependent on following the steps in Chapter 6 for copying the "glenns-theme" folder into your local Wordpress install as well as having imported the wordpress.glenns-site.xml file.

Chapter 8 - There are no lesson files for this chapter. This video is dependent on following the steps in Chapter 6 for copying the "glenns-theme" folder into your local Wordpress install as well as having imported the wordpress.glenns-site.xml file.

final_site - This folder represents the completed theme and is not used in the videos, but is provided for your reference.
│ ├── 404.php
│ ├── README.md
│ ├── footer.php
│ ├── front-page.php
│ ├── functions.php
│ ├── header.php
│ ├── images
│ │ ├── glenn-ikea.jpg
│ │ ├── hamburger.png
│ │ ├── logo-long.png
│ │ └── logo.png
│ ├── index.php
│ ├── page.php
│ ├── sidebar.php
│ ├── single.php
│ ├── style.css
│ ├── tpl_blog.php
│ └── tpl_page_with_sidebar.php
└── resources